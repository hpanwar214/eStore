
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(1, 'Pritam Pandey', 'ppmail@gmail.com', 'evfralp', '7418529630', 'indore', '90 tata nagar\r\n'),
(2, 'Harshit Panwar', 'hpanwar@gmail.com', 'lkjhgfdsa', '7893210456', 'Ratlam', 'a 133 Dindayal nagar'),
(3, 'Ashmik Pirodiya', 'apir7889@gmail.com', 'po564qa', '8520147963', 'Ujjain', '45 lakkadpitha'),
(4, 'Sidd Koch', 'sidko@gmail.com', 'po[]uit', '7449685123', 'Bhopal', 'new nagar 500\r\n\r\n'),
(5, 'Rachit Bundela', 'rb568@gmail.com', 'oigyiut', '9685741403', 'Udaipur', '87 indra nagar\r\n'),
(6, 'Sunny jain', 'sunnypaji@gmail.com', 'yhgfd000', '8959632140', 'Ratlam', '700 tata nagar'),
(7, 'Aarush Jhawa', 'aayu456@gmail.com', 'qwertyy', '8520741963', 'Mandsaur', '12 westpuri'),
(8, 'Shivam Yado', 'shiv786@gmail.com', '7845lkj', '9874123065', 'Jabalpur', '56 tanTan road'),
(9, 'Shivansh Gang', 'gangster@gmail.com', 'nhtyujm23', '9588674120', 'Khandwa', '23 pachhim pur'),
(10, 'Pushpendra labs', 'pushup@gmail.com', 'qasd8574', '7888963524', 'Shivgarh', '12 chopati'),
(12, 'saurav singh', 'ss456@gmail.com', 'bnvcx456', '7412365089', 'Dewas', '12 swara Bagh'),
(13, 'mr godrej', 'byju@yahoo.in', 'qxiom14l2', '874236910', 'Ranchi', 'vasant graph road'),
(14, 'Fazal\'s firm', 'ffmail@outlook.in', 'ij45bg', '07412-96321', 'Jaipur', 'mahalvada palace'),
(15, 'brut gold', 'brutuforce@hotmail.com', 'pokl345', '9832147506', 'Goa', '34 badi beach'),
(16, 'grady booch', 'porche@gmail.in', 'iuyt7412', '9321470560', 'Bengaluru', '12 quantum park'),
(17, 'gurur kripa', 'gkstart@rediff.in', 'xcv14nn', '7410326599', 'mumbai', '78 panvel'),
(18, 'phony admin', 'phpmy@wer.com', 'polmn41sd', '9823147506', 'Raipur', '45 navratnaa'),
(19, 'gajak singh', 'gajak@gmail.com', 'wqserd78956', '8741236955', 'Gwalior', '85,Bada bajar'),
(20, 'narendra damodar', 'namo@email.com', '741hgf258', '985214706', 'Ahmedabad', '56 shantikunj vihar'),
(21, 'eiffel chrome', 'eflieana@gmail.com', 'oplk14236', '7412589633', 'Paris', '78 sector c Eiffel tower'),
(22, 'rashmi panwar', 'rpanw@gmail.com', '74kjiu42', '9131474177', 'Indore', '8 vc dham '),
(23, 'rashmi panwar', 'rpanw@gmail.com', '74kjiu42', '9131474177', 'Indore', '8 vc dham ');
