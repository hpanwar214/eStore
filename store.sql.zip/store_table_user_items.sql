
-- --------------------------------------------------------

--
-- Table structure for table `user_items`
--

DROP TABLE IF EXISTS `user_items`;
CREATE TABLE IF NOT EXISTS `user_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('added to cart','confirmed') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_items`
--

INSERT INTO `user_items` (`id`, `user_id`, `item_id`, `status`) VALUES
(1, 5, 7, 'confirmed'),
(2, 4, 3, 'confirmed'),
(3, 9, 7, 'added to cart'),
(4, 6, 11, 'confirmed'),
(5, 3, 7, 'added to cart'),
(7, 7, 9, 'confirmed'),
(8, 6, 10, 'confirmed'),
(10, 9, 9, 'added to cart'),
(14, 8, 11, 'confirmed'),
(15, 8, 5, 'confirmed'),
(16, 8, 4, 'confirmed'),
(17, 13, 9, 'confirmed'),
(25, 4, 6, 'added to cart'),
(26, 4, 12, 'added to cart'),
(27, 8, 2, 'confirmed'),
(28, 8, 5, 'confirmed'),
(29, 8, 9, 'confirmed'),
(30, 1, 6, 'added to cart'),
(31, 1, 7, 'added to cart'),
(32, 1, 8, 'added to cart'),
(33, 1, 2, 'added to cart'),
(34, 1, 5, 'added to cart'),
(35, 1, 7, 'added to cart'),
(36, 14, 5, 'confirmed'),
(37, 14, 7, 'confirmed'),
(38, 14, 12, 'confirmed'),
(39, 14, 3, 'confirmed'),
(40, 14, 4, 'confirmed'),
(41, 14, 6, 'confirmed'),
(42, 14, 5, 'confirmed'),
(43, 14, 3, 'confirmed'),
(44, 14, 11, 'confirmed'),
(45, 14, 6, 'confirmed'),
(46, 14, 5, 'confirmed'),
(47, 14, 10, 'confirmed'),
(48, 2, 6, 'confirmed'),
(49, 2, 1, 'confirmed'),
(78, 8, 1, 'confirmed'),
(80, 8, 6, 'confirmed'),
(81, 8, 37, 'confirmed'),
(82, 8, 48, 'confirmed');
